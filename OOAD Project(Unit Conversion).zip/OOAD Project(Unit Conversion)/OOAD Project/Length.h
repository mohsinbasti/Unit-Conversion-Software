#pragma once
#include"Input.h"
class Length :public Input
{
public:
	Length();
	~Length();
	void milimeter_meter();
	void meter_milimeter();
	void centimeter_meter();
	void meter_centimeter();
	void centimeter_kilometer();
	void kilometer_centimeter();
	void meter_mile();
	void mile_meter();
	void kilometer_mile();
	void mile_kilometer();
	void feet_meter();
	void meter_feet();
	void inch_meter();
	void meter_inch();
	void yard_meter();
	void meter_yard();
};