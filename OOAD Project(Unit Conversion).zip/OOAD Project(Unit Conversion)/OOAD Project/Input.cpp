#include"Input.h"
#include<iostream>
using namespace std;

Input::Input()
{
	cout << "Default Constructor Called" << endl;
}
Input::~Input()
{
	cout << "Destructor Called" << endl;
}
void Input::setInput(float input_)
{
	input = input_;
}
float Input::getInput()
{
	return input;
}