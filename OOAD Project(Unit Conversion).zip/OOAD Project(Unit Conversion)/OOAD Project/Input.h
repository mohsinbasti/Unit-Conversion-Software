#pragma once
class Input
{
public:
	float input;
	Input();
	~Input();
	void setInput(float);
	float getInput();
};