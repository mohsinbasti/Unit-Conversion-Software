#include"Input.h"
#include"Volume.h"
#include<iostream>
using namespace std;

Volume::Volume()
{
	cout << "Constructor Called" << endl;
}
Volume::~Volume()
{
	cout << "Destructor Called" << endl;
}
void Volume::miliLiter_Liter()
{
	cout << "Mili Liter =";cin >> input;
	cout << "endl";
	cout << "Liter =" << input * .001;
}
void Volume::Liter_miliLiter()
{
	cout << "Liter =";cin >> input;
	cout << "endl";
	cout << "Mili Liter =" << input * 1000;
}
void Volume::milimeterQubic_centimeterQubic()
{
	cout << "Mili Meter Cubic =";cin >> input;
	cout << "endl";
	cout << "Centi Meter Cubic =" << input * 1000;
}
void Volume::centimeterQ_milimeterQubic()
{
	cout << "Centi Meter Cubic =";cin >> input;
	cout << "endl";
	cout << "Mili Meter Cubic =" << input * .001;
}
void Volume::centimeterQubic_meterQubic()
{
	cout << "Centi Meter Cubic =";cin >> input;
	cout << "endl";
	cout << "Meter Cubic =" << input * .000001;
}
void Volume::meterQubic_centimeterQubic()
{
	cout << "Meter Cubic =";cin >> input;
	cout << "endl";
	cout << "Centi Meter Cubic =" << input * 1000000;
}
void Volume::inchQubic_meterQubic()
{
	cout << "Inch Cubic =";cin >> input;
	cout << "endl";
	cout << "Meter Cubic =" << input * .00002;
}
void Volume::meterQubic_inchQubic()
{
	cout << "Meter Cubic =";cin >> input;
	cout << "endl";
	cout << "Inch Cubic =" << input * 61023.74409;
}
void Volume::feetQubic_meterQubic()
{
	cout << "Feet Cubic =";cin >> input;
	cout << "endl";
	cout << "Meter Cubic =" << input * 1222;
}
void Volume::meterQubic_feetQubic()
{
	cout << "Meter Cubic =";cin >> input;
	cout << "endl";
	cout << "Feet Cubic =" << input * 123;
}
void Volume::meterQubic_gallon()
{
	cout << "Meter Cubic =";cin >> input;
	cout << "endl";
	cout << "Gallon =" << input * 264.17205;
}
void Volume::gallon_meterQubic()
{
	cout << "Gallon =";cin >> input;
	cout << "endl";
	cout << "Meter Cubic =" << input * .00379;
}
void Volume::Liter_gallon()
{
	cout << "Liter =";cin >> input;
	cout << "endl";
	cout << "Gallon =" << input * .21997;
}
void Volume::gallon_Liter()
{
	cout << "Gallon =";cin >> input;
	cout << "endl";
	cout << "Liter =" << input * 4.54609;
}