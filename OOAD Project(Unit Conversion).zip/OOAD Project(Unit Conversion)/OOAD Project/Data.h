#pragma once
#include"Input.h"
class Data :public Input
{
public:
	Data();
	~Data();
	void Bit_Byte();
	void Bit_KiloByte();
	void Bit_MegaByte();
	void Bit_GigaByte();
	void Bit_TeraByte();
	void Byte_Bit();
	void Byte_KiloByte();
	void Byte_MegaByte();
	void Byte_GigaByte();
	void Byte_TeraByte();
	void KiloByte_Bit();
	void KiloByte_Byte();
	void KiloByte_MegaByte();
	void KiloByte_GigaByte();
	void KiloByte_TeraByte();
	void MegaByte_Bit();
	void MegaByte_Byte();
	void MegaByte_KiloByte();
	void MegaByte_GigaByte();
	void MegaByte_TeraByte();
	void GigaByte_Bit();
	void GigaByte_Byte();
	void GigaByte_KiloByte();
	void GigaByte_MegaByte();
	void GigaByte_TeraByte();
	void TeraByte_Bit();
	void TeraByte_Byte();
	void TeraByte_KiloByte();
	void TeraByte_MegaByte();
	void TeraByte_GigaByte();
};