#pragma once
#include"Input.h"
class Mass :public Input
{
public:
	Mass();
	~Mass();
	void milligram_gram();
	void gram_milligram();
	void gram_kilogram();
	void kilogram_gram();
	void kilogram_matricton();
	void matricton_ilogram();
	void pound_kilogram();
	void kiloggram_pound();
	void gram_pound();
	void pound_gram();
};