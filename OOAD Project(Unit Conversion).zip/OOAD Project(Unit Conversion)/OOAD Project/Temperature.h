#pragma once
#include"Input.h"
class Temperature :public Input
{
public:
	Temperature();
	void celcius_fahrenheit();
	void fahrenheit_celcius();
	void celcius_kelvin();
	void kelvin_celcius();
	void fahrenheit_kelvin();
	void kelvin_fahrenheit();
	~Temperature();
};