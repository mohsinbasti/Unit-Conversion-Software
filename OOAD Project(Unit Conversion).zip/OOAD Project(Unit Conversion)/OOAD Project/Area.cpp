#include"Input.h"
#include"Area.h"
#include<iostream>
using namespace std;

Area::Area()
{
	cout << "Default Constructor Called" << endl;
}
Area::~Area()
{
	cout << "Destructor Called" << endl;
}
void Area::milimeterSquare_centimeterSquare()
{
	cout << "Milimeter Square =";cin >> input;
	cout << endl;
	cout << "Centimeter Square =" << input * .01;
}
void Area::centimeterSquare_milimeterSquare()
{
	cout << "Centimeter Square =";cin >> input;
	cout << endl;
	cout << "Milimeter Square =" << input*100;
}
void Area::centimeterSquare_meterSquare()
{
	cout << "Centimeter Square =";cin >> input;
	cout << endl;
	cout << "Meter Square =" << input*.0001;
}
void Area::meterSquare_centimeterSquare()
{
	cout << "Meter Square =";cin >> input;
	cout << endl;
	cout << "CentiMeter Square =" << input*10000;
}
void Area::meterSquare_kilometerSquare()
{
	cout << "Meter Square =";cin >> input;
	cout << endl;
	cout << "KiloMeter Square =" << input*.000001;
}
void Area::kilometerSquare_meterSquare()
{
	cout << "Kilometer Square =";cin >> input;
	cout << endl;
	cout << "Meter Square =" << input*1000000;
}
void Area::feetSquare_meterSquare()
{
	cout << "Feet Square =";cin >> input;
	cout << endl;
	cout << "Meter Square =" << input*0.929;
}
void Area::meterSquare_feetSquare()
{
	cout << "Meter Square =";cin >> input;
	cout << endl;
	cout << "Feet Square =" << input*10.76391;
}
void Area::yardSquare_meterSquare()
{
	cout << "Yard Square =";cin >> input;
	cout << endl;
	cout << "Meter Square =" << input*.83613;
}
void Area::meterSquare_yardSquare()
{
	cout << "Meter Square =";cin >> input;
	cout << endl;
	cout << "Yard Square =" << input * 1.19599;
}
void Area::mileSquare_kilometerSquare()
{
	cout << "Miler Square =";cin >> input;
	cout << endl;
	cout << "KiloMeter Square =" << input * 2.5899;
}
void Area::kilometerSquare_mileSquare()
{
	cout << "Kilometer Square =";cin >> input;
	cout << endl;
	cout << "Mile Square =" << input * .3861;
}
void Area::acre_kilometerSquare()
{
	cout << "Arce Square =";cin >> input;
	cout << endl;
	cout << "KiloMeter Square =" << input * .40469;
}
void Area::kilometerSquare_acre()
{
	cout << "Kilometer Square =";cin >> input;
	cout << endl;
	cout << "Arce =" << input * 2.47105;
}
void Area::acre_hectare()
{
	cout << "Arce Square =";cin >> input;
	cout << endl;
	cout << "Hectare =" << input * .00405;
}
void Area::hectare_acre()
{
	cout << "Hectare Square =";cin >> input;
	cout << endl;
	cout << "Arce =" << input * 247.10538;
}