#include"Input.h"
#include"Data.h"
#include<iostream>
using namespace std;

Data::Data()
{
	cout << "Default Constructor Called" << endl;
}
Data::~Data()
{
	cout << "Destructor Called" << endl;
}
void Data::Bit_Byte()
{
	cout << "Bit =";cin >> input;
	cout << endl;
	cout << "Byte =" << input * 1;
}
void Data::Bit_KiloByte()
{
	cout << "Bit =";cin >> input;
	cout << endl;
	cout << "Kilo Byte =" << input * 1;
}
void Data::Bit_MegaByte()
{
	cout << "Bit =";cin >> input;
	cout << endl;
	cout << "Mega Byte =" << input * 1;
}
void Data::Bit_GigaByte()
{
	cout << "Bit =";cin >> input;
	cout << endl;
	cout << "Giga Byte =" << input * 1;
}
void Data::Bit_TeraByte()
{
	cout << "Bit =";cin >> input;
	cout << endl;
	cout << "Tera Byte =" << input * 1;
}
void Data::Byte_Bit()
{
	cout << "Byte =";cin >> input;
	cout << endl;
	cout << "Bit =" << input * 1;
}
void Data::Byte_KiloByte()
{
	cout << "Byte =";cin >> input;
	cout << endl;
	cout << "Kilo Byte =" << input * 1;
}
void Data::Byte_MegaByte()
{
	cout << "Byte =";cin >> input;
	cout << endl;
	cout << "Mega Byte =" << input * 1;
}
void Data::Byte_GigaByte()
{
	cout << "Byte =";cin >> input;
	cout << endl;
	cout << "Giga Byte =" << input * 1;
}
void Data::Byte_TeraByte()
{
	cout << "Byte =";cin >> input;
	cout << endl;
	cout << "Tera Byte =" << input * 1;
}
void Data::KiloByte_Bit()
{
	cout << "Kilo Byta =";cin >> input;
	cout << endl;
	cout << "Bit =" << input * 1;
}
void Data::KiloByte_Byte()
{
	cout << "Kilo Byte =";cin >> input;
	cout << endl;
	cout << "Byte =" << input * 1;
}
void Data::KiloByte_MegaByte()
{
	cout << "Kilo Byte =";cin >> input;
	cout << endl;
	cout << "Mega Byte =" << input * 1;
}
void Data::KiloByte_GigaByte()
{
	cout << "Kilo Byte =";cin >> input;
	cout << endl;
	cout << "Giga Byte =" << input * 1;
}
void Data::KiloByte_TeraByte()
{
	cout << "Kilo Byte =";cin >> input;
	cout << endl;
	cout << "Tera Byte =" << input * 1;
}
void Data::MegaByte_Bit()
{
	cout << "Mega Byte =";cin >> input;
	cout << endl;
	cout << "Bit =" << input * 1;
}
void Data::MegaByte_Byte()
{
	cout << "Mega Byte =";cin >> input;
	cout << endl;
	cout << "Byte =" << input * 1;
}
void Data::MegaByte_KiloByte()
{
	cout << "Mega Byte =";cin >> input;
	cout << endl;
	cout << "Kilo Byte =" << input * 1;
}
void Data::MegaByte_GigaByte()
{
	cout << "Mega Byte =";cin >> input;
	cout << endl;
	cout << "Giga Byte =" << input * 1;
}
void Data::MegaByte_TeraByte()
{
	cout << "Mega Byte =";cin >> input;
	cout << endl;
	cout << "Tera Byte =" << input * 1;
}
void Data::GigaByte_Bit()
{
	cout << "Giga Byte =";cin >> input;
	cout << endl;
	cout << "Bit =" << input * 1;
}
void Data::GigaByte_Byte()
{
	cout << "Giga Byte =";cin >> input;
	cout << endl;
	cout << "Byte =" << input * 1 ;
}
void Data::GigaByte_KiloByte()
{
	cout << "Giga Byte =";cin >> input;
	cout << endl;
	cout << "Kilo Byte =" << input * 1;
}
void Data::GigaByte_MegaByte()
{
	cout << "Giga Byte =";cin >> input;
	cout << endl;
	cout << "Mega Byte =" << input * 1;
}
void Data::GigaByte_TeraByte()
{
	cout << "Giga Byte =";cin >> input;
	cout << endl;
	cout << "Tera Byte =" << input * 1;
}
void Data::TeraByte_Bit()
{
	cout << "Tera Byte =";cin >> input;
	cout << endl;
	cout << "Bit =" << input * 1;
}
void Data::TeraByte_Byte()
{
	cout << "Tera Byte =";cin >> input;
	cout << endl;
	cout << "Byte =" << input * 1;
}
void Data::TeraByte_KiloByte()
{
	cout << "Tera Byte =";cin >> input;
	cout << endl;
	cout << "Kilo Byte =" << input * 1;
}
void Data::TeraByte_MegaByte()
{
	cout << "Tera Byte =";cin >> input;
	cout << endl;
	cout << "Mega Byte =" << input * 1;
}
void Data::TeraByte_GigaByte()
{
	cout << "Tera Byte =";cin >> input;
	cout << endl;
	cout << "Giga Byte =" << input * 1;
}