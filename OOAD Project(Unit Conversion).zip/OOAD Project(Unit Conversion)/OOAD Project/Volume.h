#pragma once
#include"Input.h"
class Volume :public Input
{
public:
	Volume();
	void miliLiter_Liter();
	void Liter_miliLiter();
	void milimeterQubic_centimeterQubic();
	void centimeterQ_milimeterQubic();
	void centimeterQubic_meterQubic();
	void meterQubic_centimeterQubic();
	void inchQubic_meterQubic();
	void meterQubic_inchQubic();
	void feetQubic_meterQubic();
	void meterQubic_feetQubic();
	void meterQubic_gallon();
	void gallon_meterQubic();
	void Liter_gallon();
	void gallon_Liter();
	~Volume();
};