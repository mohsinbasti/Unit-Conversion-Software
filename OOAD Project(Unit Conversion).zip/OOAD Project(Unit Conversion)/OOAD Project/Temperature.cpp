#include"Input.h"
#include"Temperature.h"
#include<iostream>
using namespace std;

Temperature::Temperature()
{
	cout << "Constructor Called" << endl;
}
Temperature::~Temperature()
{
	cout << "Destructor Called" << endl;
}
void Temperature::celcius_fahrenheit()
{
	cout << "Celcius =";cin >> input;
	cout << endl;
	cout << "Fahrenheit =" << (((9 * input) / 5) + 32);
}
void Temperature::fahrenheit_celcius()
{
	cout << "Fahrenheit =";cin >> input;
	cout << endl;
	cout << "Celcius =" << (((input - 32) / 9) * 5);
}
void Temperature::celcius_kelvin()
{
	cout << "Celcius =";cin >> input;
	cout << endl;
	cout << "Kelvin =" << input + 273;
}
void Temperature::kelvin_celcius()
{
	cout << "Kelvin =";cin >> input;
	cout << endl;
	cout << "Celcius =" << input - 273;
}
void Temperature::fahrenheit_kelvin()
{
	cout << "Fahrenheit =";cin >> input;
	cout << endl;
	cout << "Kelvin =" << (input + 459.67) * 5 / 9;
}
void Temperature::kelvin_fahrenheit()
{
	cout << "Kelvin =";cin >> input;
	cout << endl;
	cout << "Fahrenheit =" << 9 / 5 * (input - 273) + 32;
}