#include"Area.h"
#include"Data.h"
#include"Input.h"
#include"Length.h"
#include"Mass.h"
#include"Temperature.h"
#include"Volume.h"
#include<iostream>
#include<conio.h>
using namespace std;

void Welcome()
{
	cout << "                        Welcome To The" << endl;
	cout << "                           Of World" << endl;
	cout << "                    	Unit Conversion Software" << endl << endl;
}

void Menu()
{
	cout << "Enter 1 For Conversion Of  Length:" << endl;
	cout << "Enter 2 For Conversion Of  Temperature:" << endl;
	cout << "Enter 3 For Conversion Of  Mass:" << endl;
	cout << "Enter 4 For Conversion Of  Area:" << endl;
	cout << "Enter 5 For Conversion Of  Volume:" << endl;
	cout << "Enter 6 For Conversion Of  Data:" << endl;
	cout << "Enter 7 To Exit" << endl << endl;
}

void Menu1()
{
	cout << "Enter 1 To Convert Mili_Meter into Meter" << endl;
	cout << "Enter 2 To Convert Meter into Mili_Meter" << endl;
	cout << "Enter 3 To Convert Centi_Meter into Meter" << endl;
	cout << "Enter 4 To Convert Meter Into Centi_Meter" << endl;
	cout << "Enter 5 To Convert Centi_Meter into Kilo_Meter" << endl;
	cout << "Enter 6 To Convert Kilo_Meter into Centi_Meter" << endl;
	cout << "Enter 7 To Convert Meter into Miles" << endl;
	cout << "Enter 8 To Convert Miles Into Meter" << endl;
	cout << "Enter 9 To Convert Kilo_Meter into Miles" << endl;
	cout << "Enter 10 To Convert Miles Into Kilo_Meter" << endl;
	cout << "Enter 11 To Convert Feet into Meter" << endl;
	cout << "Enter 12 To Convert Meter into Feet" << endl;
	cout << "Enter 13 To Convert Inch into Meter" << endl;
	cout << "Enter 14 To Convert Meter into Inch" << endl;
	cout << "Enter 15 To Convert Yard Into Meter" << endl;
	cout << "Enter 16 To Convert Meter into Yard" << endl;
	cout << "Enter 17 To Go To Main Menu" << endl << endl;
}
void Menu2()
{
	cout << "1: Celsius-Fahrenheit" << endl;
	cout << "2: Fahrenheit-Celsius" << endl;
	cout << "3: Celsius-Kelvin" << endl;
	cout << "4: Kelvin-Celcius" << endl;
	cout << "5: Fahrenheit_Kelvin" << endl;
	cout << "6: Kelvin_Fahrenheit" << endl;
	cout << "7: Back to The Main Menu" << endl;
}
void Menu3()
{
	cout << "1: Milligm-Gramm";
	cout << "2: Gramm-milligm";
	cout << "3: Gramm-killogram";
	cout << "4: killoGramm-Gramm";
	cout << "5: pound-killogramm";
	cout << "6: killogramm-pound";
	cout << "7: Gramm-Pound";
	cout << "8: Pound-gramm";
	cout << "9: killogramm-Metric ton";
	cout << "10: Metric ton-Killogramm";
	cout << "11: Back to The Main Menu";
}
void Menu4()
{
	cout << "1: Square mm-Square cm";
	cout << "2: square cm-Square mm";
	cout << "3: square cm-square m";
	cout << "4: Square m-Square cm";
	cout << "5: Square m-Square km";
	cout << "6: Square km-Square m";
	cout << "7: Square feet-Square m";
	cout << "8: Square m-Square feet";
	cout << "9: Square Yard-Square m";
	cout << "10: Square m-Square yard";
	cout << "11: Square mile-Square km";
	cout << "12: Square km-Square mile";
	cout << "13: Acre-Hectare";
	cout << "14: Hectare-Acre";
	cout << "15: Square km-Acre ";
	cout << "16: Acre-Square km";
	cout << "17: Back to The Main Menu";
}
void Menu5()
{
	cout << "1 : ml-Litre";
	cout << "2 : Litre-ml";
	cout << "3 : Cubic mm-Cubic cm";
	cout << "4 : Cubic cm-Cubic mm";
	cout << "5 : Cubic cm-Cubic m";
	cout << "6 : Cubic m-Cubic cm";
	cout << "7 : Cubic Inch-Cubic m";
	cout << "8 : Cubic m-Cubic Inch";
	cout << "9 : Cubic feet-Cubic m";
	cout << "10 : Cubic m-Cubic feet";
	cout << "11 : Cubic m-Gallon (uk)";
	cout << "12 : Gallon-Cubic m";
	cout << "13 : Litre-Gallon";
	cout << "14 : Gallon-Litre";
	cout << "15 : Back to The Main Menu";
}
void Menu6()
{
	cout << "1: Bit_Byte" << endl;
	cout << "2:  Bit_KiloByte" << endl;
	cout << "3:  Bit_MegaByte" << endl;
	cout << "4:  Bit_GigaByte" << endl;
	cout << "5: Bit_TeraByte" << endl;
	cout << "6: Byte_Bit" << endl;
	cout << "7: Byte_KiloByte" << endl;
	cout << "8: Byte_MegaByte" << endl;
	cout << "9: Byte_GigaByte" << endl;
	cout << "10: Byte_TeraByte" << endl;
	cout << "11: KiloByte_Bit" << endl;
	cout << "12: KiloByte_Byte" << endl;
	cout << "13: KiloByte_MegaByte" << endl;
	cout << "14: KiloByte_GigaByte" << endl;
	cout << "15: KiloByte_TeraByte" << endl;
	cout << "16: MegaByte_Bit" << endl;
	cout << "17: MegaByte_Byte" << endl;
	cout << "18: MegaByte_KiloByte" << endl;
	cout << "19: MegaByte_GigaByte" << endl;
	cout << "20: MegaByte_TeraByte" << endl;
	cout << "21 GigaByte_Bit" << endl;
	cout << "22: GigaByte_Byte" << endl;
	cout << "23: GigaByte_KiloByte" << endl;;
	cout << "24: GigaByte_MegaByte" << endl;
	cout << "25 GigaByte_TeraByte" << endl;
	cout << "26 TeraByte_Bit" << endl;
	cout <<"27: TeraByte_Byte"<<endl;
	cout << "28: TeraByte_KiloByte" << endl;
	cout << "29: TeraByte_MegaByte" << endl;
	cout << "30: TeraByte_GigaByte" << endl;
	cout << "31: Back To Main Menu" << endl << endl;
}
int main()
{
	Area a;
	Data d;
	Length l;
	Mass m;
	Temperature t;
	Volume v;
	int choice1;
	int choice2;
	while (1)
	{
		Welcome();
		Menu();
		cout << "Please Enter Your Conversion Type :";
		cin >> choice1;

		if (choice1 = 1)
		{
			Menu1();
			while (1)
			{
				cout << "Please Enter Your Choice :";
				cin >> choice2;

				if (choice2 == 1)
				{
					l.milimeter_meter();
				}
				else if (choice2 == 2)
				{
					l.meter_milimeter();
				}
				else if (choice2 == 3)
				{
					l.centimeter_meter();
				}
				else if (choice2 == 4)
				{
					l.meter_centimeter();
				}
				else if (choice2 == 5)
				{
					l.centimeter_kilometer();
				}
				else if (choice2 == 6)
				{
					l.kilometer_centimeter();
				}
				else if (choice2 == 7)
				{
					l.meter_mile();
				}
				else if (choice2 == 8)
				{
					l.mile_meter();
				}
				else if (choice2 == 9)
				{
					l.kilometer_mile();
				}
				else if (choice2 == 10)
				{
					l.mile_kilometer();
				}
				else if (choice2 == 11)
				{
					l.feet_meter();
				}
				else if (choice2 == 12)
				{
					l.meter_feet();
				}
				else if (choice2 == 13)
				{
					l.inch_meter();
				}
				else if (choice2 == 14)
				{
					l.meter_inch();
				}
				else if (choice2 == 15)
				{
					l.yard_meter();
				}
				else if (choice2 == 16)
				{
					l.meter_yard();
				}
				else if (choice2 == 17)
				{
					break;
				}
			}
		}
		else if (choice1 == 2)
		{
			Menu2();
			while (1)
			{
				cout << "Please Enter Your Choice :";
				cin >> choice2;
				if (choice2 == 1)
				{
					t.celcius_fahrenheit();
				}
				else if (choice2 == 2)
				{
					t.fahrenheit_celcius();
				}
				else if (choice2 == 3)
				{
					t.celcius_kelvin();
				}
				else if (choice2 == 4)
				{
					t.kelvin_celcius();
				}
				else if (choice2 == 5)
				{
					t.fahrenheit_kelvin();
				}
				else if (choice2 == 6)
				{
					t.kelvin_fahrenheit();
				}
				else if (choice2 == 7)
				{
					break;
				}
			}
		}
		else if (choice1 == 3)
		{
			Menu3();
			while (1)
			{
				cout << "Please Enter Your Choice :";
				cin >> choice2;
				if (choice2 == 1)
				{
					m.milligram_gram();
				}
				else if (choice2 == 2)
				{
					m.gram_milligram();
				}
				else if (choice2 == 3)
				{
					m.gram_kilogram();
				}
				else if (choice2 == 4)
				{
					m.kilogram_gram();
				}
				else if (choice2 == 5)
				{
					m.pound_kilogram();
				}
				else if (choice2 == 6)
				{
					m.kiloggram_pound();
				}
				else if (choice2 == 7)
				{
					m.gram_pound();
				}
				else if (choice2 == 8)
				{
					m.pound_gram();
				}
				else if (choice2 == 9)
				{
					m.kilogram_matricton();
				}
				else if (choice2 == 10)
				{
					m.matricton_ilogram();
				}
				else if (choice2 == 11)
				{
					break;
				}
			}
		}
		else if (choice1 == 4)
		{
			Menu4();
			while (1)
			{
				cout << "Please Enter Your Choice :";
				cin >> choice2;
				if (choice2 == 1)
				{
					a.milimeterSquare_centimeterSquare();
				}
				else if (choice2 == 2)
				{
					a.centimeterSquare_milimeterSquare();
				}
				else if (choice2 == 3)
				{
					a.centimeterSquare_meterSquare();
				}
				else if (choice2 == 4)
				{
					a.meterSquare_centimeterSquare();
				}
				else if (choice2 == 5)
				{
					a.meterSquare_kilometerSquare();
				}
				else if (choice2 == 6)
				{
					a.kilometerSquare_meterSquare();
				}
				else if (choice2 == 7)
				{
					a.feetSquare_meterSquare();
				}
				else if (choice2 == 8)
				{
					a.meterSquare_feetSquare();
				}
				else if (choice2 == 9)
				{
					a.yardSquare_meterSquare();
				}
				else if (choice2 == 10)
				{
					a.meterSquare_yardSquare();
				}
				else if (choice2 == 11)
				{
					a.mileSquare_kilometerSquare();
				}
				else if (choice2 == 12)
				{
					a.kilometerSquare_mileSquare();
				}
				else if (choice2 == 13)
				{
					a.acre_hectare();
				}
				else if (choice2 == 14)
				{
					a.hectare_acre();
				}
				else if (choice2 == 15)
				{
					a.kilometerSquare_acre();
				}
				else if (choice2 == 16)
				{
					a.acre_kilometerSquare();
				}
				else if (choice2 == 17)
				{
					break;
				}
			}
		}
		else if (choice1 == 5)
		{
			Menu5();
			while (1)
			{
				cout << "Please Enter Your Choice :";
				cin >> choice2;
				if (choice2 == 1)
				{
					v.miliLiter_Liter();
				}
				else if (choice2 == 2)
				{
					v.Liter_miliLiter();
				}
				else if (choice2 == 3)
				{
					v.milimeterQubic_centimeterQubic();
				}
				else if (choice2 == 4)
				{
					v.centimeterQ_milimeterQubic();
				}
				else if (choice2 == 5)
				{
					v.centimeterQubic_meterQubic();
				}
				else if (choice2 == 6)
				{
					v.meterQubic_centimeterQubic();
				}
				else if (choice2 == 7)
				{
					v.inchQubic_meterQubic();
				}
				else if (choice2 == 8)
				{
					v.meterQubic_inchQubic();
				}
				else if (choice2 == 9)
				{
					v.feetQubic_meterQubic();
				}
				else if (choice2 == 10)
				{
					v.meterQubic_feetQubic();
				}
				else if (choice2 == 11)
				{
					v.meterQubic_gallon();
				}
				else if (choice2 == 12)
				{
					v.gallon_meterQubic();
				}
				else if (choice2 == 13)
				{
					v.Liter_gallon();
				}
				else if (choice2 == 14)
				{
					v.gallon_Liter();
				}
				else if (choice2 == 15)
				{
					break;
				}
			}
		}
		else if (choice1 == 6)
		{
			Menu6();
			while (1)
			{
				cout << "Plaese Enter Your Choice :";
				cin >> choice2;
				if (choice2 == 1)
				{
					d.Bit_Byte();
				}
				if (choice2 == 2)
				{
					d.Bit_KiloByte();
				}
				if (choice2 == 3)
				{
					d.Bit_MegaByte();
				}
				if (choice2 == 4)
				{
					d.Bit_GigaByte();
				}
				if (choice2 == 5)
				{
					d.Bit_TeraByte();
				}
				if (choice2 == 6)
				{
					d.Byte_Bit();
				}
				if (choice2 == 7)
				{
					d.Byte_KiloByte();
				}
				if (choice2 == 8)
				{
					d.Byte_MegaByte();
				}
				if (choice2 == 9)
				{
					d.Byte_GigaByte();
				}
				if (choice2 == 10)
				{
					d.Byte_TeraByte();
				}
				if (choice2 == 11)
				{
					d.KiloByte_Bit();
				}
				if (choice2 == 12)
				{
					d.KiloByte_Byte();
				}
				if (choice2 == 13)
				{
					d.KiloByte_MegaByte();
				}
				if (choice2 == 14)
				{
					d.KiloByte_GigaByte();
				}
				if (choice2 == 15)
				{
					d.KiloByte_TeraByte();
				}
				if (choice2 == 16)
				{
					d.MegaByte_Bit();
				}
				if (choice2 == 17)
				{
					d.MegaByte_Byte();
				}
				if (choice2 == 18)
				{
					d.MegaByte_KiloByte();
				}
				if (choice2 == 19)
				{
					d.MegaByte_GigaByte();
				}
				if (choice2 == 20)
				{
					d.MegaByte_TeraByte();
				}
				if (choice2 == 21)
				{
					d.GigaByte_Bit();
				}
				if (choice2 == 22)
				{
					d.GigaByte_Byte();
				}
				if (choice2 == 23)
				{
					d.GigaByte_KiloByte();
				}
				if (choice2 == 24)
				{
					d.GigaByte_MegaByte();
				}
				if (choice2 == 25)
				{
					d.GigaByte_TeraByte();
				}
				if (choice2 == 26)
				{
					d.TeraByte_Bit();
				}
				if (choice2 == 27)
				{
					d.TeraByte_Byte();
				}
				if (choice2 == 28)
				{
					d.TeraByte_KiloByte();
				}
				if (choice2 == 29)
				{
					d.TeraByte_MegaByte();
				}
				if (choice2 == 30)
				{
					d.TeraByte_GigaByte();
				}
				if (choice2 == 31)
				{
					break;
				}
			}
		}
		else if (choice1 == 7)
		{
			break;
		}
	}

	return 0;
}