#pragma once
#include"Input.h"
class Area :public Input
{
public:
	Area();
	void milimeterSquare_centimeterSquare();
	void centimeterSquare_milimeterSquare();
	void centimeterSquare_meterSquare();
	void meterSquare_centimeterSquare();
	void meterSquare_kilometerSquare();
	void kilometerSquare_meterSquare();
	void feetSquare_meterSquare();
	void meterSquare_feetSquare();
	void yardSquare_meterSquare();
	void meterSquare_yardSquare();
	void mileSquare_kilometerSquare();
	void kilometerSquare_mileSquare();
	void acre_kilometerSquare();
	void kilometerSquare_acre();
	void acre_hectare();
	void hectare_acre();
	~Area();
};