#include"Input.h"
#include"Mass.h"
#include<iostream>
using namespace std;

Mass::Mass()
{
	cout << "Constructor Called" << endl;
}
Mass::~Mass()
{
	cout << "Destructor Called" << endl;
}
void Mass::milligram_gram()
{
	cout << "Mili Gram =";cin >> input;
	cout << endl;
	cout << "Gram =" << input * .001;
}
void Mass::gram_milligram()
{
	cout << "Gram =";cin >> input;
	cout << endl;
	cout << "Mili Gram =" << input * 1000;
}
void Mass::gram_kilogram()
{
	cout << "Gram =";cin >> input;
	cout << endl;
	cout << "Kilo Gram =" << input * .001;
}
void Mass::kilogram_gram()
{
	cout << "Kilo Gram =";cin >> input;
	cout << endl;
	cout << "Gram =" << input * 1000;
}
void Mass::kilogram_matricton()
{
	cout << "Kilo Gram =";cin >> input;
	cout << endl;
	cout << "Matric Ton =" << input * .001;
}
void Mass::matricton_ilogram()
{
	cout << "Matric Ton =";cin >> input;
	cout << endl;
	cout << "Kilo Gram =" << input * 1000;
}
void Mass::pound_kilogram()
{
	cout << "Pound =";cin >> input;
	cout << endl;
	cout << "Kilo Gram =" << input * .45359;
}
void Mass::kiloggram_pound()
{
	cout << "Kilo Gram =";cin >> input;
	cout << endl;
	cout << "Pound =" << input * 2.20462;
}
void Mass::gram_pound()
{
	cout << "Gram =";cin >> input;
	cout << endl;
	cout << "Pound =" << input * .0022;
}
void Mass::pound_gram()
{
	cout << "Pound =";cin >> input;
	cout << endl;
	cout << "Gram =" << input * 453.59237;
}