#include"Input.h"
#include"Length.h"
#include<iostream>
using namespace std;

Length::Length()
{
	cout << "Constructor Called" << endl;
}
Length::~Length()
{
	cout << "Destructor Called" << endl;
}
void Length::milimeter_meter()
{
	cout << "Milimeter is =";cin >> input;
	cout << endl;
	cout << "Meter is =" << input * .001;
}
void Length::meter_milimeter()
{
	cout << "meter is =";cin >> input;
	cout << endl;
	cout << "MiliMeter is =" << input * 1000;
}
void Length::centimeter_meter()
{
	cout << "Centimeter is =";cin >> input;
	cout << endl;
	cout << "Meter is =" << input * .01;
}
void Length::meter_centimeter()
{
	cout << "meter is =";cin >> input;
	cout << endl;
	cout << "CentiMeter is =" << input *100 ;
}
void Length::centimeter_kilometer()
{
	cout << "Centimeter is =";cin >> input;
	cout << endl;
	cout << "KiloMeter is =" << input * .00062;
}
void Length::kilometer_centimeter()
{
	cout << "Kilometer is =";cin >> input;
	cout << endl;
	cout << "CentiMeter is =" << input * 1609.344;
}
void Length::meter_mile()
{
	cout << "meter is =";cin >> input;
	cout << endl;
	cout << "Mile is =" << input * 0.00001;
}
void Length::mile_meter()
{
	cout << "Mile is =";cin >> input;
	cout << endl;
	cout << "Meter is =" << input * 100000;
}
void Length::kilometer_mile()
{
	cout << "Kilometer is =";cin >> input;
	cout << endl;
	cout << "Mile is =" << input * .3048;
}
void Length::mile_kilometer()
{
	cout << "Mile is =";cin >> input;
	cout << endl;
	cout << "KiloMeter is =" << input * 3.28084;
}
void Length::feet_meter()
{
	cout << "Feet is =";cin >> input;
	cout << endl;
	cout << "Meter is =" << input * 0.9144;
}
void Length::meter_feet()
{
	cout << "Meter is =";cin >> input;
	cout << endl;
	cout << "Feet is =" << input * 1.09361;
}
void Length::inch_meter()
{
	cout << "Inch is =";cin >> input;
	cout << endl;
	cout << "Meter is =" << input * .0254;
}
void Length::meter_inch()
{
	cout << "Meter is =";cin >> input;
	cout << endl;
	cout << "Inch is =" << input * 39.37008;
}
void Length::yard_meter()
{
	cout << "Yard is =";cin >> input;
	cout << endl;
	cout << "Meter is =" << input * .6213712;
}
void Length::meter_yard()
{
	cout << "Meter is =";cin >> input;
	cout << endl;
	cout << "Yard is =" << input * 1.60934;
}